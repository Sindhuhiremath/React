import React from 'react'
import './About.css'
import about from '../../assets/about.png'
import play_icon from '../../assets/play_icon.png'

const About = () => {
  return (
    <div className='about'>
        <div className="about-left">
            <img src={about} alt="" className='about-img'/>
            <img src={play_icon} alt="" className='play_icon' />
        </div>
        <div className="about-right">
            <h3>ABOUT UNIVERSITY</h3>
            <h2>Nurturing Tomorrow's Leaders Today</h2>
            <p>A university (from Latin universitas 'a whole') is an institution of higher (or tertiary) education and research which awards academic degrees in several academic disciplines.[1] University is derived from the Latin phrase universitas magistrorum et scholarium, which roughly means "community of teachers and scholars".[2] Universities typically offer both undergraduate and postgraduate programs.</p>

            <p>A university (from Latin universitas 'a whole') is an institution of higher (or tertiary) education and research which awards academic degrees in several academic disciplines.[1] University is derived from the Latin phrase universitas magistrorum et scholarium, which roughly means "community of teachers and scholars".[2] Universities typically offer both undergraduate and postgraduate programs.</p>

            <p>A university (from Latin universitas 'a whole') is an institution of higher (or tertiary) education and research which awards academic degrees in several academic disciplines.[1] University is derived from the Latin phrase universitas magistrorum et scholarium, which roughly means "community of teachers and scholars".[2] Universities typically offer both undergraduate and postgraduate programs.</p>
        </div>
    </div>
  )
}

export default About 